export interface commentDetails {
    name: string;
    comment : string;
}