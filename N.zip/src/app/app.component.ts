import { Component, OnInit } from '@angular/core';
import {
  AngularFireStorage,
  AngularFireStorageReference,
  AngularFireUploadTask,
} from '@angular/fire/storage';

import { concat, defer, Observable } from 'rxjs';
import { filter, finalize, map } from 'rxjs/operators';

import { commentDetails } from './commentStructure/commentModel';
import { CommentServiceService } from './comment-service.service';

import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'videoManag';
  ref: AngularFireStorageReference;
  task: AngularFireUploadTask;
  uploadProgress: Observable<number>;
  downloadURL: Observable<string>;
  uploadState: Observable<string>;
  status: String = 'Intializing Upload';

  icon = 'fa fa-spinner';
  icon_1 = 'fa fa-check-circle';

  comments: commentDetails[] = [];

  userForm: FormGroup = new FormGroup({
    comment: new FormControl(''),
  });

  constructor(
    private afStorage: AngularFireStorage,
    private commentSerive: CommentServiceService
  ) {}

  ngOnInit(): void {
    this.comments = this.commentSerive.getComments();
  }

  upload(event) {
    console.log('upload called');
    const id = Math.random().toString(36).substring(2);
    this.updateStatusUploading();
    this.ref = this.afStorage.ref(id);
    console.log('After ref');
    this.task = this.ref.put(event.target.files[0]);
    console.log('After task');
    this.uploadProgress = this.task.percentageChanges();
    this.uploadState = this.task.snapshotChanges().pipe(
      map((s) => s.state),
      finalize(() => {
        console.log('After finalize');
        this.updateStatus();
        status = 'upload complete';
        this.ref.getDownloadURL().subscribe((url) => {
          this.downloadURL = url;
          console.log('this property :', this.downloadURL);
        });
      })
    );
  }
  updateStatusUploading() {
    this.status = 'Uploading ....';
  }

  numberOfLikes: number = 0;
  titles = 'likes so far';
  likeButtonClick() {
    this.numberOfLikes++;
  }

  updateStatus() {
    this.status = 'Completed ..!';
  }

  addToComments() {
    const newComment: commentDetails = {
      name: 'anonymous',
      comment: this.userForm.get('comment').value,
    };
    this.commentSerive.addComment(newComment);
  }
}
