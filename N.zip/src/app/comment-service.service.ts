import { Injectable } from '@angular/core';
import { commentDetails } from './commentStructure/commentModel';
import {BehaviorSubject, Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommentServiceService {

  comments : commentDetails[] = [
    {
      name: "Nikhil",
      comment : "this is comment 1"
    },
    {
      name: "Vishnu",
      comment : "this is comment 2"
    },
    {
      name: "Rashi",
      comment : "this is comment 3"
    },
    {
      name: "Srihita",
      comment : "this is comment 4"
    }
  ]

  public _category = new BehaviorSubject('');
  constructor() { }
  getComments() {
    return this.comments;
  }

  addComment(comment : commentDetails){
    console.log("in service",comment);
    this.comments.push(comment);
  }

  emit<T>(data : string){
    this._category.next(data);
  }

  on<T> () :  Observable<string> {
    return this._category.asObservable();
  }
}
